// Copyright Grama Nicolae 2018
#include <stdlib.h>
#include "game.h"

int main() {
    startGame();
    return 0;
}
